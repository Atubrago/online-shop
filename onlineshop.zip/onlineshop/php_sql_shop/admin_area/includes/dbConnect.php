<?php 

$con = mysqli_connect("localhost", "root", "" , "php_sql_shop");
//show this message if failed to connect to server
if(mysqli_connect_errno()){
echo "failed to connect to Mysql Server :" . mysqli_connect_error();
}

?>