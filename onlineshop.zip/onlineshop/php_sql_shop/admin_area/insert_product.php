<!DOCTYPE html>

<?php
include("includes/dbConnect.php");
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>insert product</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/insert_product.css">
    <script src="js/jQuery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/5/tinymce.min.js"></script>
  <script>tinymce.init({selector:'textarea'});</script>
  
</head>
<body>
    
    <!--Inserting form for products-->
    <div class="container">
        <form action="insert_product.php" method="post" enctype="multipart/form-data">
    <table class="table-bordered">
    <tr>
    <td colspan="2"><h2 class="text-center title">Inserting form</h2></td>
    </tr>
    <tr>
    <td>product title:</td>
    <td><input type="text" name="product_title"></td>
    </tr>
    <td>product catecory:</td>
    <td><select name="product_cat" id="product_cat">
    <option value="">select category</option>
    <?php
$get_cats = "select * from categories";
    $run_cats = mysqli_query($con, $get_cats);
     
    while ($row_cats=mysqli_fetch_array($run_cats)){
        $cat_id = $row_cats['cat_id'];
        $cat_title = $row_cats['cat_title'];
        
        echo "<option value='$cat_id'> $cat_title </option>";

    }
    ?>
    </select></td>
    </tr>
    <td>product brand:</td>
    <td><select name="product_brand" id="product_brand">
    <option value="">select brand</option>
    <?php
$get_brands = "select * from brands";
$run_brands = mysqli_query($con, $get_brands);
 
while ($row_brands=mysqli_fetch_array($run_brands)){
    $brand_id = $row_brands['brand_id'];
    $brand_title = $row_brands['brand_title'];
    
    echo "<option value='$brand_id'> $brand_title </option>";

}

?>
    </select></td>
    </tr>
    <td>product image:</td>
    <td><input type="file" name="product_image"></td>
    </tr>
    <td>product price:</td>
    <td><input type="text" name="product_price"></td>
    </tr>
    <td>product description:</td>
    <td><textarea name="product_desc" id="product_desc" cols="30" rows="10"></textarea></td>
    </tr>
    <td>product keywords:</td>
    <td><input type="text" name="product_keywords"></td>
    </tr>
    <tr>
    <td colspan="2"><button type="submit" name="insert_post" class="btn btn-primary btn-sm">Insert Now:</button></td>
    </tr>
    </table>
    </form>
    </div>

    <!--php inserting script for inserting the production into database-->
    <?php
if (isset($_POST['insert_post'])){
    //getting the text data From the Fields
    $product_title = $_POST['product_title'];
    $product_cat = $_POST['product_cat'];
    $product_brand = $_POST['product_brand'];
    $product_price = $_POST['product_price'];
    $product_desc = $_POST['product_desc'];
    $product_keywords = $_POST['product_keywords'];

    //getting the image from the field
    $product_image = $_FILES['product_image']['name'];
    $product_image_tmp = $_FILES['product_image']['tmp_name'];
    move_uploaded_file($product_image_tmp, "product_images/$product_image");

    //sql query to insert data to database
    $insert_product = "insert into products (product_title,product_cat,product_brand,product_price,product_image,product_desc,product_keywords) values (' $product_title', '$product_cat', '$product_brand',' $product_price','$product_image',' $product_desc','$product_keywords')";

   $insert_pro = mysqli_query($con, $insert_product);

   if( $insert_pro){
       echo "<script>alert('product inserted successfully!')</script>";
       echo "<script>window.open('insert_product.php','_self')</script>";
   }
}
    ?>
</body>
</html>