<?php 

$con = mysqli_connect("localhost", "root", "" , "php_sql_shop");
//show this message if failed to connect to server
if(mysqli_connect_errno()){
    echo "failed to connect to Mysql Server :" . mysqli_connect_error();
    }

//getting categories

function getcats(){
    global $con;
    $get_cats = "select * from categories";
    $run_cats = mysqli_query($con, $get_cats);
     
    while ($row_cats=mysqli_fetch_array($run_cats)){
        $cat_id = $row_cats['cat_id'];
        $cat_title = $row_cats['cat_title'];
        
        echo "<li> <a href='index.php?cat=$cat_id'>$cat_title</a> </li>";

    }

}

//getting Brans

function getbrands(){
    global $con;
    $get_brands = "select * from brands";
    $run_brands = mysqli_query($con, $get_brands);
     
    while ($row_brands=mysqli_fetch_array($run_brands)){
        $brand_id = $row_brands['brand_id'];
        $brand_title = $row_brands['brand_title'];
        
        echo "<li> <a href='index.php?brand=$brand_id'>$brand_title</a> </li>";

    }

}


//Displaying products randomly by a limited number;
 function displaypro(){
     if(!isset($_GET['cat'])){

        
        if(!isset($_GET['brand'])){

     
     global $con;
     $get_pro = "select * from products order by RAND() LIMIT 0,9";
     $run_pro = mysqli_query($con, $get_pro);

     while($row_pro=mysqli_fetch_array($run_pro)){
      $product_id = $row_pro['product_id'];
      $product_cat = $row_pro['product_cat'];
      $product_brand = $row_pro['product_brand'];
      $product_title = $row_pro['product_title'];
      $product_price = $row_pro['product_price'];
      $product_image = $row_pro['product_image'];

      echo "
      <div class='col-lg-4 col-md-4 col-sm-6 col-xs-12 display-single'>
      <h3>$product_title</h3>
    <img src='admin_area/product_images/$product_image' width='220' height='220' class='img-rounded' />
      <p> <b>$ $product_price</b></p>
      
      <a href='details.php?product_id=$product_id' style='float:left; font-size:20;color:blue;'><b>Details</b></a>
      <a href='index.php?product_id=$product_id' style='float:right' class='btn btn-primary'>Add to cart</a>
      </div>
      
      ";
     
     }
    }
    }
 }

//Displaying products by category;
function displayproBYcat(){
    if(isset($_GET['cat'])){
        $cat_id=$_GET['cat'];
    
    global $con;
    $get_cat_pro = "select * from products where Product_cat=$cat_id";
    $run_cat_pro = mysqli_query($con, $get_cat_pro);

    $count_cats=mysqli_num_rows($run_cat_pro);
    if(   $count_cats==0){
        echo "<h2 style='background-color:blue; color:white; height:80px;'>There is no product in this category !.<br> kindly check later</h2>";
    }

    while($row_cat_pro=mysqli_fetch_array($run_cat_pro)){
     $product_id = $row_cat_pro['product_id'];
     $product_cat = $row_cat_pro['product_cat'];
     $product_brand = $row_cat_pro['product_brand'];
     $product_title = $row_cat_pro['product_title'];
     $product_price = $row_cat_pro['product_price'];
     $product_image = $row_cat_pro['product_image'];

     echo "
     <div class='col-lg-4 col-md-4 col-sm-6 col-xs-12 display-single'>
     <h3>$product_title</h3>
   <img src='admin_area/product_images/$product_image' width='220' height='220' class='img-rounded' />
     <p> <b>$ $product_price</b></p>
     
     <a href='details.php?product_id=$product_id' style='float:left; font-size:20;color:blue;'><b>Details</b></a>
     <a href='index.php?product_id=$product_id' style='float:right' class='btn btn-primary'>Add to cart</a>
     </div>
     
     ";
    
    }
   }
   
}

//Displaying products by brands;
function displayproBYbrand(){
    if(isset($_GET['brand'])){
        $brand_id=$_GET['brand'];
    
    global $con;
    $get_brand_pro = "select * from products where Product_brand=$brand_id";
    $run_brand_pro = mysqli_query($con, $get_brand_pro);

    $count_brands=mysqli_num_rows($run_brand_pro);
    if(   $count_brands==0){
        echo "<h2 style='background-color:blue; color:white; height:80px;'>There is no product for the brand selected !.<br> Kindly check later !</h2>";
    }

    while($row_brand_pro=mysqli_fetch_array($run_brand_pro)){
     $product_id = $row_brand_pro['product_id'];
     $product_cat = $row_brand_pro['product_cat'];
     $product_brand = $row_brand_pro['product_brand'];
     $product_title = $row_brand_pro['product_title'];
     $product_price = $row_brand_pro['product_price'];
     $product_image = $row_brand_pro['product_image'];

     echo "
     <div class='col-lg-4 col-md-4 col-sm-6 col-xs-12 display-single'>
     <h3>$product_title</h3>
   <img src='admin_area/product_images/$product_image' width='220' height='220' class='img-rounded' />
     <p> <b>$ $product_price</b></p>
     
     <a href='details.php?product_id=$product_id' style='float:left; font-size:20;color:blue;'><b>Details</b></a>
     <a href='index.php?product_id=$product_id' style='float:right' class='btn btn-primary'>Add to cart</a>
     </div>
     
     ";
    
    }
   }
   
}


?>