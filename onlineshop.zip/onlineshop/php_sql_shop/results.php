<!DOCTYPE html>
<?php 
include("functions/functions.php");
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>online shop</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/index.css">
    <script src="js/jQuery.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
<!--Start of top navigation-->
   <nav class="navbar navbar-inverse" role="navigagion">
   <div class="navbar-header">
   <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
   <span class="sr-only">toggle navigation</span>
   <span class="icon-bar"></span>
   <span class="icon-bar"></span>
   <span class="icon-bar"></span>
   </button>
   <a class="navbar-brand" href="index.php">online shop</a>
   </div>
   <div class="navbar-collapse collapse">
   <ul class="nav navbar-nav">
   <li class="active "><a href="index.php">home</a></li>
   <li class=""><a href="all_products.php">All products</a></li>
   <li class=""><a href="customer/my_account.php">account</a></li>
   <li class=""><a href="#">blog</a></li>
   </ul>
  <!--Search bar start-->
  <div class="top-serah-bar">
  <form action="results.php" method="get" enctype="multipart/form-data" >
  <input type="text" name="user_query" >
  <input type="submit" name="search" id="search" value="search">
  </form>
  </div>
    <!--Search bar End-->
   </div>
   </nav>
   <!--End of top navigation-->

   <!--Start of main body-->

   <div class="container">
   <!-- Side bar start-->
   <div class="row">
   <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12 side_bar-all-products">
       <!--Categories start-->
       <ul id="cats">
       <li class="nav-header list-unstyled">Categories</li>
           <?php getcats(); ?>
       </ul>
       <!-- Categories end -->

       <!--brands start-->
       
       <ul id="brands">
           <li class="nav-header list-unstyled">Brands</li>
          <?php getbrands(); ?>
       </ul>
        <!--brands end-->
        
        <!--products start-->
        <ul>
        <li class="nav-header list-unstyled">Products</li>
        </ul>
     
          <!--products end-->
   
   </div>
    <!-- Side bar end-->
    <!--Main content start-->
    <div class="col-lg-10 col-md-10 col-sm-10 col-xs-12  main_content-all-products">
    <!--shopping cart start-->
    <div class="shopping_cart">
        <span style="color:black;">
        <b style="color:white;">Welcome Guest!</b>
            <b style="color:yellow;">Shopping Cart - </b>
            <b>Total Items: </b>
            <b>Total Price: </b>
            <a href="#">Go to Cart</a>
        </span>
     </div>
    <!--shopping cart End-->
    <div class="row">
    <!--php script for displaying products by search query-->
    <?php
    if (isset($_GET['search'])){
       $search_query= $_GET['user_query'];
   
    $get_pro = "select * from products where product_keywords or  product_title like '%$search_query%'";
    $run_pro = mysqli_query($con, $get_pro);

    while($row_pro=mysqli_fetch_array($run_pro)){
     $product_id = $row_pro['product_id'];
     $product_cat = $row_pro['product_cat'];
     $product_brand = $row_pro['product_brand'];
     $product_title = $row_pro['product_title'];
     $product_price = $row_pro['product_price'];
     $product_image = $row_pro['product_image'];

     echo "
     <div class='col-lg-4 col-md-4 col-sm-6 col-xs-12 display-single'>
     <h3>$product_title</h3>
   <img src='admin_area/product_images/$product_image' width='220' height='220' class='img-rounded' />
     <p> <b>$ $product_price</b></p>
     
     <a href='details.php?product_id=$product_id' style='float:left; font-size:20;color:blue;'><b>Details</b></a>
     <a href='index.php?product_id=$product_id' style='float:right' class='btn btn-primary'>Add to cart</a>
     </div>
    
     ";
    }
    }
    ?>
    </div>
    </div>
     <!--Main content end-->
   </div>
  
   </div>
</body>
</html>