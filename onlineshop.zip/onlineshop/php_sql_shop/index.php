<!DOCTYPE html>
<?php 
include("functions/functions.php");
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>online shop</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/index.css">
    <script src="js/jQuery.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
<!--Start of top navigation-->
   <nav class="navbar navbar-inverse" role="navigagion">
   <div class="navbar-header">
   <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
   <span class="sr-only">toggle navigation</span>
   <span class="icon-bar"></span>
   <span class="icon-bar"></span>
   <span class="icon-bar"></span>
   </button>
   <a class="navbar-brand" href="index.php">online shop</a>
   </div>
   <div class="navbar-collapse collapse">
   <ul class="nav navbar-nav">
   <li class="active "><a href="index.php">home</a></li>
   <li class=""><a href="all_products.php">All products</a></li>
   <li class=""><a href="customer/my_account.php">account</a></li>
   <li class=""><a href="#">blog</a></li>
   </ul>
  <!--Search bar start-->
  <div class="top-serah-bar">
  <form action="results.php" method="get" enctype="multipart/form-data" >
  <input type="text" name="user_query" >
  <input type="submit" name="search" id="search" value="search">
  </form>
  </div>
    <!--Search bar End-->
   </div>
   </nav>
   <!--End of top navigation-->

   <!--Start of main body-->

   <div class="container">
   <!-- Side bar start-->
   <div class="row">
   <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12 side_bar">
       <!--Categories start-->
       <ul id="cats">
       <li class="nav-header list-unstyled">Categories</li>
           <?php getcats(); ?>
       </ul>
       <!-- Categories end -->

       <!--brands start-->
       
       <ul id="brands">
           <li class="nav-header list-unstyled">Brands</li>
          <?php getbrands(); ?>
       </ul>
        <!--brands end-->
        
        <!--products start-->
        <ul>
        <li class="nav-header list-unstyled">Products</li>
        </ul>
     
          <!--products end-->
   
   </div>
    <!-- Side bar end-->
    <!--Main content start-->
    <div class="col-lg-10 col-md-10 col-sm-10 col-xs-12  main_content">
    <!--shopping cart start-->
    <div class="shopping_cart">
        <span style="color:black;">
        <b style="color:white;">Welcome Guest!</b>
            <b style="color:yellow;">Shopping Cart - </b>
            <b>Total Items: </b>
            <b>Total Price: </b>
            <a href="#">Go to Cart</a>
        </span>
     </div>
    <!--shopping cart End-->
    <div class="row">
    <!--php script for displaying products-->
    <?php
    //display random products
displaypro();
    // display product by category
    displayproBYcat();
    //display products by brands
    displayproBYbrand();
    ?>
    </div>
    </div>
     <!--Main content end-->
   </div>
  
   </div>
</body>
</html>